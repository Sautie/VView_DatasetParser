rm(list = ls())
status_poids <-list()

Weights_w <- function(df, dataDemoW, status, slevel) {

  patients<-unique(df$UID_NUMERO_PATIENT)
  LPatients<-length(patients)
  print(LPatients)
  POIDS_g<-c()

  for(i in 1:LPatients) {
    auxw<-c()
    auxstatus<-c()
    for(j in 1:length(dataDemoW$UID_NUMERO_PATIENT)) {
    if (df$UID_NUMERO_PATIENT[i] ==dataDemoW$UID_NUMERO_PATIENT[j]){
      if (dataDemoW$POIDS_G[j]<15000){
          auxw<-append(auxw,dataDemoW$POIDS_G[j])
          auxstatus<-append(auxstatus, slevel)
      }
    }
    }
    auxw<-unique(auxw)
    #auxstatus<-rep(slevel, each=length(auxw))
    if (length(auxstatus)>0) {
    POIDS_g<-c(POIDS_g,auxw[length(auxw)])
    status<-append(status,auxstatus[length(auxstatus)] )
  }

  }
  status_poids <-list("w"=POIDS_g, "s"=status)
  return(status_poids)
}

Weights_Dw <- function(df, dataDemoW, status, slevel) {

  patients<-unique(df$UID_NUMERO_PATIENT)
  LPatients<-length(patients)
  print(LPatients)
  POIDS_g<-c()

  for(i in 1:LPatients) {
    auxw<-c()
    auxstatus<-c()
    for(j in 1:length(dataDemoW$UID_NUMERO_PATIENT)) {
      if (df$UID_NUMERO_PATIENT[i] ==dataDemoW$UID_NUMERO_PATIENT[j]){
        if (dataDemoW$POIDS_G[j]<15000){
          auxw<-append(auxw,dataDemoW$POIDS_G[j])
          auxstatus<-append(auxstatus, slevel)
        }
      }
    }
    auxw<-unique(auxw)
    #auxstatus<-rep(slevel, each=length(auxw))
    if ((length(auxstatus)>0)&&(auxw[length(auxw)]-auxw[1]>0)) {
       POIDS_g<-c(POIDS_g,auxw[length(auxw)]-auxw[1])
       status<-append(status,auxstatus[length(auxstatus)] )
    }

  }
  status_poids <-list("w"=POIDS_g, "s"=status)
  return(status_poids)
}

Weights_Mw <- function(df, dataDemoW, status, slevel, m="mean") {

  patients<-unique(df$UID_NUMERO_PATIENT)
  LPatients<-length(patients)
  print(LPatients)
  POIDS_g<-c()

  for(i in 1:LPatients) {
    auxw<-c()
    auxstatus<-c()
    for(j in 1:length(dataDemoW$UID_NUMERO_PATIENT)) {
      if (df$UID_NUMERO_PATIENT[i] ==dataDemoW$UID_NUMERO_PATIENT[j]){
        if (dataDemoW$POIDS_G[j]<15000){
          auxw<-append(auxw,dataDemoW$POIDS_G[j])
          auxstatus<-append(auxstatus, slevel)
        }
      }
    }
    auxw<-unique(auxw)
    #auxstatus<-rep(slevel, each=length(auxw))
   if (length(auxstatus)>0) {
    if (m=="mean") {
      POIDS_g<-c(POIDS_g, mean(auxw))
      status<-append(status,auxstatus[length(auxstatus)])
      }
    else if (m=="mx") {
      POIDS_g<-c(POIDS_g, max(auxw))
      status<-append(status,auxstatus[length(auxstatus)])
    }
    else if (m=="mn") {
      POIDS_g<-c(POIDS_g, min(auxw))
      status<-append(status,auxstatus[length(auxstatus)])
    }

    if ((m=="mdif")&&(auxw[length(auxw)]-auxw[1]>0)) {
      POIDS_g<-c(POIDS_g,  mean(diff(auxw)))
      status<-append(status,auxstatus[length(auxstatus)])
    }

    else if ((m=="madif")&&(auxw[length(auxw)]-auxw[1]>0)){
      POIDS_g<-c(POIDS_g,  max(diff(auxw)))
      status<-append(status,auxstatus[length(auxstatus)])
    }
     else if ((m=="midif")&&(auxw[length(auxw)]-auxw[1]>0)){
      POIDS_g<-c(POIDS_g,  min(diff(auxw)))
      status<-append(status,auxstatus[length(auxstatus)])
   }

   } }
  status_poids <-list("w"=POIDS_g, "s"=status)
  return(status_poids)
}

df <- read.csv("3nov2022ProjetAI_dxOU.csv", sep = ";", encoding="UTF-8", header=TRUE)
dfH <- read.csv("3nov2022ProjetAI_dxHealthy.csv", sep = ";", encoding="UTF-8", header=TRUE)

dataDemoW<- read.csv("1nov2022ProjetAI_signesVitauxW.csv", sep = ";", encoding="UTF-8", header=TRUE, na = c('', '0', '2', '4', '6'))
print(apply(dataDemoW, 2, function(col)sum(is.na(col))/length(col)))
dataDemoW <-dataDemoW[!is.na(dataDemoW$POIDS_G),]
status<-c()
slevel<-"OU"
r<-Weights_Mw(df, dataDemoW, status, slevel, m="midif")
slevel<-"H"
status<- r$s
POIDSou<- r$w
rr<-Weights_Mw(dfH, dataDemoW, status, slevel, m="midif")
status<- rr$s
POIDSH<- rr$w

#mean max  min last first-last meandiff madiff midiff
Weight<-append(POIDSou, POIDSH)

dfw<-data.frame(Weight, status)
dfw$status<- factor(dfw$status)

p<-ggplot(dfw, aes(x=Weight, fill=status))+
  geom_boxplot(notch=TRUE)+scale_fill_brewer(palette="Dark2")
p
