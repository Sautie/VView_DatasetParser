# rm(list = ls())
# library(lubridate)
# df <- read.csv("1nov2022ProjetAI_dxW.csv", sep = ";", encoding="UTF-8", header=TRUE)
#
# #data1<-df[df$DX_CODEE %in% c('Examen Normal Pré-Opératoire', 'Examen Normal','Examen Normal Vaccination','Vaccination','Voir Plus Bas', 'Diagnostic(S) Primaire(S)','Codage De Diagnostic','Diagnostic(S) Secondaire(S)', 'Diagnostic ouvert'))]
# #data1<- df[grepl("Diagnostic", df$DX_CODEE),]
# data<-df[!(df$DX_CODEE %in% c('Examen Normal Pré-Opératoire', 'Examen Normal','Examen Normal Vaccination','Vaccination','Voir Plus Bas' , 'Diagnostic(S) Primaire(S)','Codage De Diagnostic','Diagnostic(S) Secondaire(S)', 'Diagnostic ouvert')),]
# data1<-df[df$DX_CODEE %in% c('Examen Normal Vaccination','Vaccination'),]
#
#
# DX_CODEEs<-unique(data$DX_CODEE)
# LDX_CODEE<-length(DX_CODEEs)
# print(LDX_CODEE)
#
# #age, sex, race
#
# dataDemo <- read.csv("1nov2022ProjetAI_patientDemographicsW.csv", sep = ";", encoding="UTF-8", header=TRUE, na = c('', '###############################################################################################################################################################################################################################################################'))
# nal<-print(apply(dataDemo, 2, function(col)sum(is.na(col))/length(col)))
# dataDemo <-dataDemo[!is.na(dataDemo$DATE_NAISSANCE),]
# Demo_patients<-unique(dataDemo$UID_NUMERO_PATIENT)
# LDemo_patients<-length(Demo_patients)
# print(LDemo_patients)
#
# aux<-0
# age<-c()    # for DX_CODEEs all
# for(i in 1:length(dataDemo$UID_NUMERO_PATIENT)) {
#   for(j in 1:length(df$UID_NUMERO_PATIENT)) {
#     if (dataDemo$UID_NUMERO_PATIENT[i] ==df$UID_NUMERO_PATIENT[j])  {
#       aux<-as.numeric(difftime( ymd(substring(df$DERNIERE_MODIF_LE[j],1,10)), ymd(substring(dataDemo$DATE_NAISSANCE[i],1,10)), units = "days"))/ 365.25
#       if (aux>0) {age<-append(age,aux)} #possible date errors in file
#   }}
# }
#
# ageP<-c()  # only for diseases
# for(i in 1:length(dataDemo$UID_NUMERO_PATIENT)) {
#   for(j in 1:length(data$UID_NUMERO_PATIENT)) {
#     if (dataDemo$UID_NUMERO_PATIENT[i] ==data$UID_NUMERO_PATIENT[j]) {
#       aux<-as.numeric(difftime(ymd(substring(data$DERNIERE_MODIF_LE[j],1,10)), ymd(substring(dataDemo$DATE_NAISSANCE[i],1,10)), units = "days"))/ 365.25
#     if (aux>0) {ageP<-append(ageP,aux)}
#     }
#   }
# }
#
# age1<-c()  # only for diseases
# for(i in 1:length(dataDemo$UID_NUMERO_PATIENT)) {
#   for(j in 1:length(data1$UID_NUMERO_PATIENT)) {
#     if (dataDemo$UID_NUMERO_PATIENT[i] ==data1$UID_NUMERO_PATIENT[j]) {
#       aux<-as.numeric(difftime(ymd(substring(data1$DERNIERE_MODIF_LE[j],1,10)), ymd(substring(dataDemo$DATE_NAISSANCE[i],1,10)), units = "days"))/ 365.25
#       if (aux>0) {age1<-append(age1,aux)}
#     }
#   }
# }
#
# dff<-data.frame(age)
# write.csv(dff,file='ages_ALL.csv',row.names=FALSE)
#
# #
# # ggplot(dff, aes(x = age1)) +
# #   geom_histogram(aes(y = ..density..), colour = 1, fill = "white") +
# #   geom_density(lwd = 1, colour = 3,fill = 3, alpha = 0.25)
#
# dff<-data.frame(age1)
# write.csv(dff,file='ages_HealthyCats.csv',row.names=FALSE)
#
# # ggplot(dff, aes(x = age1)) +
# #   geom_histogram(aes(y = ..density..), colour = 1, fill = "white") +
# #   geom_density(lwd = 1, colour = 2,fill = 2, alpha = 0.25)
#
# dff<-data.frame(ageP)
# write.csv(dff,file='ages_DX_CODE.csv',row.names=FALSE)

# ggplot(dff, aes(x = age)) +
#   geom_histogram(aes(y = ..density..), colour = 1, fill = "white") +
#   geom_density(lwd = 1, colour = 4,fill = 4, alpha = 0.25)

######################################### race

rm(list = ls())
library(lubridate)
df <- read.csv("1nov2022ProjetAI_dxW.csv", sep = ";", encoding="UTF-8", header=TRUE)

dataDemoRace <- read.csv("1nov2022ProjetAI_patientDemographicsW.csv", sep = ";", encoding="UTF-8", header=TRUE, na = c(''))
print(apply(dataDemoRace, 2, function(col)sum(is.na(col))/length(col)))
dataDemoRace <-dataDemoRace[!is.na(dataDemoRace$RACE),]

#race and sex distributions for patients with diagnostics
race<-c()  # ALL
for(i in 1:length(dataDemoRace$UID_NUMERO_PATIENT)) {
      race<-append(race,dataDemoRace$RACE[i])
}

raced<-c()  # for DX_CODEEs
for(i in 1:length(dataDemoRace$UID_NUMERO_PATIENT)) {
  for(ii in 1:length(df$UID_NUMERO_PATIENT))
    if (df$UID_NUMERO_PATIENT[ii]== dataDemoRace$UID_NUMERO_PATIENT[i])
      raced<-append(raced,dataDemoRace$RACE[i])
}

racedC<-c()  # without healthy cats
for(i in 1:length(dataDemoRace$UID_NUMERO_PATIENT)) {
  for(ii in 1:length(data$UID_NUMERO_PATIENT))
    if (data$UID_NUMERO_PATIENT[ii]== dataDemoRace$UID_NUMERO_PATIENT[i])
      racedC<-append(racedC,dataDemoRace$RACE[i])
}

racedH<-c()  # healthy
for(i in 1:length(dataDemoRace$UID_NUMERO_PATIENT)) {
  for(ii in 1:length(data1$UID_NUMERO_PATIENT))
    if (data1$UID_NUMERO_PATIENT[ii]== dataDemoRace$UID_NUMERO_PATIENT[i])
      racedH<-append(racedH,dataDemoRace$RACE[i])
}


# ######################################### race
#
#
# df_raceALL<-data.frame(table(race)) #for all cats
# df_raceALL<-df_raceALL[df_raceALL$Freq < 700,]
# df_raceALL$race<-factor(df_raceALL$race)
# df_raceALL$race<- factor(df_raceALL$race, levels = df_raceALL$race[order(df_raceALL$Freq, decreasing = TRUE)])
#
# df_raceD<-data.frame(table(raced))   #for diagnosed cats
# df_raceD<-df_raceD[df_raceD$Freq < 700,]
# df_raceD$raced<-factor(df_raceD$raced)
# df_raceD$raced<- factor(df_raceD$raced, levels = df_raceD$raced[order(df_raceD$Freq, decreasing = TRUE)])
#
# df_racewH<-data.frame(table(racedC)) # without healthy cats
# df_racewH<-df_racewH[df_racewH$Freq < 700,]
# df_racewH$racedC<-factor(df_racewH$racedC)
# df_racewH$racedC<- factor(df_racewH$racedC, levels = df_racewH$racedC[order(df_racewH$Freq, decreasing = TRUE)])
#
#
# df_raceH<-data.frame(table(racedH))  # healthy cats
# df_raceH<-df_raceH[df_raceH$Freq < 700,]
# df_raceH$racedH<-factor(df_raceH$racedH)
# df_raceH$racedH<- factor(df_raceH$racedH, levels = df_raceH$racedH[order(df_raceH$Freq, decreasing = TRUE)])
#
#
# write.csv(odf,file='raceALLfr.csv',row.names=FALSE)
# write.csv(df_raceD,file='race_DX_CODEEfr.csv',row.names=FALSE)
# write.csv(df_racewH,file='race_wHealthyfr.csv',row.names=FALSE)
# write.csv(df_raceH,file='race_withHealthyfr.csv',row.names=FALSE)

# df <- data.frame(DX_CODEEs,patients)
# df$DX_CODEEs<-factor(df$DX_CODEEs)
# df$DX_CODEEs<- factor(df$DX_CODEEs, levels = df$DX_CODEEs[order(df$patients, decreasing = TRUE)])
#
# ggplot(data=df_raceH, aes(x=racedH, y=Freq))+
#   geom_bar(stat="identity", fill="antiquewhite4")+
#   geom_text(aes(label=Freq),  vjust=-0.3, size=3)+
#   #geom_line(aes(x=reorder(patient, -obs), y=obs),  size = 0.8, color="red", group = 1)
#   theme(text = element_text(size=12))+
#   theme_grey() + theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))


######################################### SEX ##################################

# rm(list = ls())
# library(lubridate)
# df <- read.csv("1nov2022ProjetAI_dxW.csv", sep = ";", encoding="UTF-8", header=TRUE)
#
# data<-df[!(df$DX_CODEE %in% c('Examen Normal Pré-Opératoire', 'Examen Normal','Examen Normal Vaccination','Vaccination','Voir Plus Bas' , 'Diagnostic(S) Primaire(S)','Codage De Diagnostic','Diagnostic(S) Secondaire(S)', 'Diagnostic ouvert')),]
# data1<-df[df$DX_CODEE %in% c('Examen Normal Vaccination','Vaccination'),]


# DX_CODEEs<-unique(data$DX_CODEE)
# LDX_CODEE<-length(DX_CODEEs)
# print(LDX_CODEE)
# dataDemoSex <- read.csv("1nov2022ProjetAI_patientDemographicsW.csv", sep = ";", encoding="UTF-8", header=TRUE, na = c('', 'Non Déterminé'))
# print(apply(dataDemoSex, 2, function(col)sum(is.na(col))/length(col)))
# dataDemoSex <-dataDemoSex[!is.na(dataDemoSex$SEXE),]
#
# # all cats in the database
# sexM<-c()
# sexS<-c()
# sex<-c()
# for(i in 1:length(dataDemoSex$UID_NUMERO_PATIENT)) {
#
#     if ((dataDemoSex$SEXE[i]=="Femelle Stérilisée")||(dataDemoSex$SEXE[i]=="Femelle"))
#     {sex<-append(sex,"Femelle")}
#     else if ((dataDemoSex$SEXE[i]=="Mâle Stérilisé")||(dataDemoSex$SEXE[i]=="Mâle")||(dataDemoSex$SEXE[i]=="Hongre"))
#     {  sex<-append(sex,"Mâle") }
#
#      if (dataDemoSex$SEXE[i]=="Hongre")
#      {sexM<-append(sexM,"Mâle Stérilisé") }
#     else
#     {sexM<-append(sexM,dataDemoSex$SEXE[i]) }
#
#   if ((dataDemoSex$SEXE[i]=="Femelle Stérilisée")||(dataDemoSex$SEXE[i]=="Mâle Stérilisé")||(dataDemoSex$SEXE[i]=="Hongre"))
#      {sexS<-append(sexS,"Stérilisé") }
#   else
#      {sexS<-append(sexS,"Non-Stérilisé") }
#
# }
#
# # all cats in the database
# df_sexF_M<-data.frame(table(sex)) # femelle_Male
# df_sexM<-data.frame(table(sexM))  # multiple s
# df_sexS<-data.frame(table(sexS))  # Stérilisé/non_s
#
# df_sexF_M$sex<-factor(df_sexF_M$sex)
# df_sexF_M$sex<- factor(df_sexF_M$sex, levels = df_sexF_M$sex[order(df_sexF_M$Freq, decreasing = TRUE)])
#
# df_sexM$sexM<-factor(df_sexM$sexM)
# df_sexM$sexM<- factor(df_sexM$sexM, levels = df_sexM$sexM[order(df_sexM$Freq, decreasing = TRUE)])
#
# df_sexS$sexS<-factor(df_sexS$sexS)
# df_sexS$sexS<- factor(df_sexS$sexS, levels = df_sexS$sexS[order(df_sexS$Freq, decreasing = TRUE)])
#
#
# write.csv(df_sexF_M,file='sexF_M.csv',row.names=FALSE)
# write.csv(df_sexM,file='sexM.csv',row.names=FALSE)
# write.csv(df_sexS,file='sexS.csv',row.names=FALSE)
#
# ggplot(data=df_sexF_M, aes(x=sex, y=Freq))+
#   geom_bar(stat="identity", fill="darkorange3", width = 0.5)+
#   geom_text(aes(label=Freq),  vjust=-0.3, size=3)+
#   #geom_line(aes(x=reorder(patient, -obs), y=obs),  size = 0.8, color="red", group = 1)
#   theme(text = element_text(size=12))+
#   theme_grey() + theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))
#
# ggplot(data=df_sexS, aes(x=sexS, y=Freq))+
#   geom_bar(stat="identity", fill="darkorange3", width = 0.3)+
#   geom_text(aes(label=Freq),  vjust=-0.3, size=3)+
#   #geom_line(aes(x=reorder(patient, -obs), y=obs),  size = 0.8, color="red", group = 1)
#   theme(text = element_text(size=12))+
#   theme_grey() + theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))
#
# ggplot(data=df_sexM, aes(x=sexM, y=Freq))+
#   geom_bar(stat="identity", fill="darkorange3", width = 0.5)+
#   geom_text(aes(label=Freq),  vjust=-0.3, size=3)+
#   #geom_line(aes(x=reorder(patient, -obs), y=obs),  size = 0.8, color="red", group = 1)
#   theme(text = element_text(size=12))+
#   theme_grey() + theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))
#
#
# # only for cats with DX_CODEEs
# sexd<-c()
# sexMd<-c()
# sexSd<-c()
# for(i in 1:length(dataDemoSex$UID_NUMERO_PATIENT)) {
#   for(ii in 1:length(df$UID_NUMERO_PATIENT))
#     if (df$UID_NUMERO_PATIENT[ii]== dataDemoSex$UID_NUMERO_PATIENT[i]) {
#       if ((dataDemoSex$SEXE[i]=="Femelle Stérilisée")||(dataDemoSex$SEXE[i]=="Femelle"))
#         {sexd<-append(sexd,"Femelle")}
#       else if ((dataDemoSex$SEXE[i]=="Mâle Stérilisé")||(dataDemoSex$SEXE[i]=="Mâle")||(dataDemoSex$SEXE[i]=="Hongre"))
#         {sexd<-append(sexd,"Mâle") }
#
#       if (dataDemoSex$SEXE[i]=="Hongre")
#         {sexMd<-append(sexMd,"Mâle Stérilisé") }
#       else
#         {sexMd<-append(sexMd,dataDemoSex$SEXE[i]) }
#
#       if ((dataDemoSex$SEXE[i]=="Femelle Stérilisée")||(dataDemoSex$SEXE[i]=="Mâle Stérilisé")||(dataDemoSex$SEXE[i]=="Hongre"))
#         {sexSd<-append(sexSd,"Stérilisé") }
#       else
#         {sexSd<-append(sexSd,"Non-Stérilisé") }
#     }
# }
#
# #only for DX_CODEEs
# df_sexdF_M<-data.frame(table(sexd)) # femelle_Male
# df_sexdM<-data.frame(table(sexMd))  # multiple s
# df_sexdS<-data.frame(table(sexSd)) # Stérilisé/non_s
#
# df_sexdF_M$sex<-factor(df_sexdF_M$sexd)
# df_sexdF_M$sex<- factor(df_sexdF_M$sexd, levels = df_sexdF_M$sexd[order(df_sexdF_M$Freq, decreasing = TRUE)])
#
# df_sexdM$sexMd<-factor(df_sexdM$sexMd)
# df_sexdM$sexMd<- factor(df_sexdM$sexMd, levels = df_sexdM$sexMd[order(df_sexdM$Freq, decreasing = TRUE)])
#
# df_sexdS$sexSd<-factor(df_sexdS$sexSd)
# df_sexdS$sexSd<- factor(df_sexdS$sexSd, levels = df_sexdS$sexSd[order(df_sexdS$Freq, decreasing = TRUE)])
#
#
# write.csv(df_sexdF_M,file='sexF_M_DX_CODEE.csv',row.names=FALSE)
# write.csv(df_sexdM,file='sexM_DX_CODEE.csv',row.names=FALSE)
# write.csv(df_sexdS,file='sexS_DX_CODEE.csv',row.names=FALSE)
#
# ggplot(data=df_sexdF_M, aes(x=sexd, y=Freq))+
#   geom_bar(stat="identity", fill="darkorange3", width = 0.5)+
#   geom_text(aes(label=Freq),  vjust=-0.3, size=3)+
#   #geom_line(aes(x=reorder(patient, -obs), y=obs),  size = 0.8, color="red", group = 1)
#   theme(text = element_text(size=12))+
#   theme_grey() + theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))
#
# ggplot(data=df_sexdM, aes(x=sexMd, y=Freq))+
#   geom_bar(stat="identity", fill="darkorange3", width = 0.5)+
#   geom_text(aes(label=Freq),  vjust=-0.3, size=3)+
#   #geom_line(aes(x=reorder(patient, -obs), y=obs),  size = 0.8, color="red", group = 1)
#   theme(text = element_text(size=12))+
#   theme_grey() + theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))
#
# ggplot(data=df_sexdS, aes(x=sexSd, y=Freq))+
#   geom_bar(stat="identity", fill="darkorange3", width = 0.5)+
#   geom_text(aes(label=Freq),  vjust=-0.3, size=3)+
#   #geom_line(aes(x=reorder(patient, -obs), y=obs),  size = 0.8, color="red", group = 1)
#   theme(text = element_text(size=12))+
#   theme_grey() + theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))
#
# #for data without healthy and some other cats
# sexdC<-c()
# sexMdC<-c()
# sexSdC<-c()
# for(i in 1:length(dataDemoSex$UID_NUMERO_PATIENT)) {
#   for(ii in 1:length(data$UID_NUMERO_PATIENT)) {
#     if (data$UID_NUMERO_PATIENT[ii]== dataDemoSex$UID_NUMERO_PATIENT[i])
#     {
#       if ((dataDemoSex$SEXE[i]=="Femelle Stérilisée")||(dataDemoSex$SEXE[i]=="Femelle"))
#       {sexdC<-append(sexdC,"Femelle")}
#       else if ((dataDemoSex$SEXE[i]=="Mâle Stérilisé")||(dataDemoSex$SEXE[i]=="Mâle")||(dataDemoSex$SEXE[i]=="Hongre"))
#       {sexdC<-append(sexdC,"Mâle") }
#
#       if (dataDemoSex$SEXE[i]=="Hongre")
#       {sexMdC<-append(sexMdC,"Mâle Stérilisé") }
#       else
#       {sexMdC<-append(sexMdC,dataDemoSex$SEXE[i]) }
#
#       if ((dataDemoSex$SEXE[i]=="Femelle Stérilisée")||(dataDemoSex$SEXE[i]=="Mâle Stérilisé")||(dataDemoSex$SEXE[i]=="Hongre"))
#       {sexSdC<-append(sexSdC,"Stérilisé") }
#       else
#       {sexSdC<-append(sexSdC,"Non-Stérilisé") }
#     }
# }  }
# #for data without healthy and some other cats
# df_sexdCF_M<-data.frame(table(sexdC)) # femelle_Male
# df_sexdCM<-data.frame(table(sexMdC)) # multiple s
# df_sexdCS<-data.frame(table(sexSdC)) # Stérilisé/non_s
#
# df_sexdCF_M$sexdC<-factor(df_sexdCF_M$sexdC)
# df_sexdCF_M$sexdC<- factor(df_sexdCF_M$sexdC, levels = df_sexdCF_M$sexdC[order(df_sexdCF_M$Freq, decreasing = TRUE)])
#
# df_sexdCM$sexMdC<-factor(df_sexdCM$sexMdC)
# df_sexdCM$sexMdC<- factor(df_sexdCM$sexMdC, levels = df_sexdCM$sexMdC[order(df_sexdCM$Freq, decreasing = TRUE)])
#
# df_sexdCS$sexSdC<-factor(df_sexdCS$sexSdC)
# df_sexdCS$sexSdC<- factor(df_sexdCS$sexSdC, levels = df_sexdCS$sexSdC[order(df_sexdCS$Freq, decreasing = TRUE)])
#
# write.csv(df_sexdCF_M,file='sexF_M_wHealthyOther.csv',row.names=FALSE)
# write.csv(df_sexdCM,file='sexMult_wHealthyOther.csv',row.names=FALSE)
# write.csv(df_sexdCS,file='sexSnS_wHealthyOther.csv',row.names=FALSE)
#
# ggplot(data=df_sexdCF_M, aes(x=sexdC, y=Freq))+
#   geom_bar(stat="identity", fill="darkorange3", width = 0.5)+
#   geom_text(aes(label=Freq),  vjust=-0.3, size=3)+
#   #geom_line(aes(x=reorder(patient, -obs), y=obs),  size = 0.8, color="red", group = 1)
#   theme(text = element_text(size=12))+
#   theme_grey() + theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))
#
# ggplot(data=df_sexdCM, aes(x=sexMdC, y=Freq))+
#   geom_bar(stat="identity", fill="darkorange3", width = 0.5)+
#   geom_text(aes(label=Freq),  vjust=-0.3, size=3)+
#   #geom_line(aes(x=reorder(patient, -obs), y=obs),  size = 0.8, color="red", group = 1)
#   theme(text = element_text(size=12))+
#   theme_grey() + theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))
#
# ggplot(data=df_sexdCS, aes(x=sexSdC, y=Freq))+
#   geom_bar(stat="identity", fill="darkorange3", width = 0.5)+
#   geom_text(aes(label=Freq),  vjust=-0.3, size=3)+
#   #geom_line(aes(x=reorder(patient, -obs), y=obs),  size = 0.8, color="red", group = 1)
#   theme(text = element_text(size=12))+
#   theme_grey() + theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))
#
# #for data  of healthy cats
# sexdH<-c()
# sexMdH<-c()
# sexSdH<-c()
#
# for(i in 1:length(dataDemoSex$UID_NUMERO_PATIENT)) {
#   for(ii in 1:length(data1$UID_NUMERO_PATIENT))
#     if (data1$UID_NUMERO_PATIENT[ii]== dataDemoSex$UID_NUMERO_PATIENT[i])
#     {
#       if ((dataDemoSex$SEXE[i]=="Femelle Stérilisée")||(dataDemoSex$SEXE[i]=="Femelle"))
#       {sexdH<-append(sexdC,"Femelle")}
#       else if ((dataDemoSex$SEXE[i]=="Mâle Stérilisé")||(dataDemoSex$SEXE[i]=="Mâle")||(dataDemoSex$SEXE[i]=="Hongre"))
#       {sexdH<-append(sexdC,"Mâle") }
#
#       if (dataDemoSex$SEXE[i]=="Hongre")
#       {sexMdH<-append(sexMdC,"Mâle Stérilisé") }
#       else
#       {sexMdH<-append(sexMdC,dataDemoSex$SEXE[i]) }
#
#       if ((dataDemoSex$SEXE[i]=="Femelle Stérilisée")||(dataDemoSex$SEXE[i]=="Mâle Stérilisé")||(dataDemoSex$SEXE[i]=="Hongre"))
#       {sexSdH<-append(sexSdC,"Stérilisé") }
#       else
#       {sexSdH<-append(sexSdC,"Non-Stérilisé") }
#     }
# }
#
# #for data of healthy cats
# df_sexdHF_M<-data.frame(table(sexdH)) # femelle_Male
# df_sexdHM<-data.frame(table(sexMdH))  # multiple s
# df_sexdHS<-data.frame(table(sexSdH))  # Sntérilisé/non_s
#
# df_sexdHF_M$sexdH<-factor(df_sexdHF_M$sexdH)
# df_sexdHF_M$sexdH<- factor(df_sexdHF_M$sexdH, levels = df_sexdHF_M$sexdH[order(df_sexdHF_M$Freq, decreasing = TRUE)])
#
# df_sexdHM$sexMdH<-factor(df_sexdHM$sexMdH)
# df_sexdHM$sexMdH<- factor(df_sexdHM$sexMdH, levels = df_sexdHM$sexMdH[order(df_sexdHM$Freq, decreasing = TRUE)])
#
# df_sexdHS$sexSdH<-factor(df_sexdHS$sexSdH)
# df_sexdHS$sexSdH<- factor(df_sexdHS$sexSdH, levels = df_sexdHS$sexSdH[order(df_sexdHS$Freq, decreasing = TRUE)])
#
# ggplot(data=df_sexdHF_M, aes(x=sexdH, y=Freq))+
#   geom_bar(stat="identity", fill="darkorange3", width = 0.5)+
#   geom_text(aes(label=Freq),  vjust=-0.3, size=3)+
#   #geom_line(aes(x=reorder(patient, -obs), y=obs),  size = 0.8, color="red", group = 1)
#   theme(text = element_text(size=12))+
#   theme_grey() + theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))
#
# ggplot(data=df_sexdHM, aes(x=sexMdH, y=Freq))+
#   geom_bar(stat="identity", fill="darkorange3", width = 0.5)+
#   geom_text(aes(label=Freq),  vjust=-0.3, size=3)+
#   #geom_line(aes(x=reorder(patient, -obs), y=obs),  size = 0.8, color="red", group = 1)
#   theme(text = element_text(size=12))+
#   theme_grey() + theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))
#
# ggplot(data=df_sexdHS, aes(x=sexSdH, y=Freq))+
#   geom_bar(stat="identity", fill="darkorange3", width = 0.5)+
#   geom_text(aes(label=Freq),  vjust=-0.3, size=3)+
#   #geom_line(aes(x=reorder(patient, -obs), y=obs),  size = 0.8, color="red", group = 1)
#   theme(text = element_text(size=12))+
#   theme_grey() + theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))
#
#
# ## falta figuras
#
# write.csv(df_sexdHF_M,file='sexF_M_Healthy.csv',row.names=FALSE)
# write.csv(df_sexdHM,file='sexMult_Healthy.csv',row.names=FALSE)
# write.csv(df_sexdHS,file='sex_SnS_Healthy.csv',row.names=FALSE)

##########################################################################################3
#
# rm(list = ls())
# library(lubridate)
# df <- read.csv("1nov2022ProjetAI_dxW.csv", sep = ";", encoding="UTF-8", header=TRUE)
#
# data<-df[!(df$DX_CODEE %in% c('Examen Normal Pré-Opératoire', 'Examen Normal','Examen Normal Vaccination','Vaccination','Voir Plus Bas' , 'Diagnostic(S) Primaire(S)','Codage De Diagnostic','Diagnostic(S) Secondaire(S)', 'Diagnostic ouvert')),]
# data1<-df[df$DX_CODEE %in% c('Examen Normal Vaccination','Vaccination'),]
#
#
# DX_CODEEs<-unique(data$DX_CODEE)
# LDX_CODEE<-length(DX_CODEEs)
# print(LDX_CODEE)
#
# dataDemoCouleur <- read.csv("1nov2022ProjetAI_patientDemographicsW.csv", sep = ";", encoding="UTF-8", header=TRUE, na = c(''))
# print(apply(dataDemoCouleur, 2, function(col)sum(is.na(col))/length(col)))
# dataDemoCouleur <-dataDemoCouleur[!is.na(dataDemoCouleur$COULEUR),]
#
# couleur<-c()
# for(i in 1:length(dataDemoCouleur$UID_NUMERO_PATIENT)) {
#   couleur<-append(couleur,dataDemoCouleur$COULEUR[i])
# }
#
# couleurd<-c()
# for(i in 1:length(dataDemoCouleur$UID_NUMERO_PATIENT)) {
#   for(ii in 1:length(df$UID_NUMERO_PATIENT)){
#     if (df$UID_NUMERO_PATIENT[ii]== dataDemoCouleur$UID_NUMERO_PATIENT[i]) {
#       couleurd<-append(couleurd,dataDemoCouleur$COULEUR[i])
#       }
#     }
# }
#
# couleurdC<-c()
# for(i in 1:length(dataDemoCouleur$UID_NUMERO_PATIENT)) {
#   for(ii in 1:length(data$UID_NUMERO_PATIENT)) {
#     if (data$UID_NUMERO_PATIENT[ii]== dataDemoCouleur$UID_NUMERO_PATIENT[i]) {
#       couleurdC<-append(couleurdC,dataDemoCouleur$COULEUR[i])
#     }
#   }
# }
#
# couleurdH<-c()  # healthy
# for(i in 1:length(dataDemoCouleur$UID_NUMERO_PATIENT)) {
#   for(ii in 1:length(data1$UID_NUMERO_PATIENT))
#     if (data1$UID_NUMERO_PATIENT[ii]== dataDemoCouleur$UID_NUMERO_PATIENT[i])
#       couleurdH<-append(couleurdH,dataDemoCouleur$COULEUR[i])
# }
#
#
# df_couleurALL<-data.frame(table(couleur)) #for all cats
# df_couleurALL<-df_couleurALL[df_couleurALL$Freq >10,]
# df_couleurALL$couleur<-factor(df_couleurALL$couleur)
# df_couleurALL$couleur<- factor(df_couleurALL$couleur, levels = df_couleurALL$couleur[order(df_couleurALL$Freq, decreasing = TRUE)])
#
# df_couleurD<-data.frame(table(couleurd))   #for diagnosed cats
# df_couleurD<-df_couleurD[df_couleurD$Freq >10,]
# df_couleurD$couleurd<-factor(df_couleurD$couleurd)
# df_couleurD$couleurd<- factor(df_couleurD$couleurd, levels = df_couleurD$couleurd[order(df_couleurD$Freq, decreasing = TRUE)])
#
# df_couleurC<-data.frame(table(couleurdC)) # without healthy cats
# df_couleurC<-df_couleurC[df_couleurC$Freq >10,]
# df_couleurC$couleurdC<-factor(df_couleurC$couleurdC)
# df_couleurC$couleurdC<- factor(df_couleurC$couleurdC, levels = df_couleurC$couleurdC[order(df_couleurC$Freq, decreasing = TRUE)])
# #
#
# df_couleurH<-data.frame(table(couleurdH)) # without healthy cats
# df_couleurH<-df_couleurH[df_couleurH$Freq >10,]
# df_couleurH$couleurdH<-factor(df_couleurH$couleurdH)
# df_couleurH$couleurdH<- factor(df_couleurH$couleurdH, levels = df_couleurH$couleurdH[order(df_couleurH$Freq, decreasing = TRUE)])
# #
#
#
# # write.csv(df_couleurALL,file='couleurALL.csv',row.names=FALSE)
# # write.csv(df_couleurD,file='couleurD.csv',row.names=FALSE)
# # write.csv(df_couleurC,file='couleurC.csv',row.names=FALSE)
# # write.csv(df_couleurH,file='couleurH.csv',row.names=FALSE)
#
#
# ggplot(data=df_couleurH, aes(x=couleurdH, y=Freq))+
#   geom_bar(stat="identity", fill="chartreuse4")+
#   geom_text(aes(label=Freq),  vjust=-0.3, size=3)+
#   #geom_line(aes(x=reorder(patient, -obs), y=obs),  size = 0.8, color="red", group = 1)
#   theme(text = element_text(size=12))+
#   theme_grey() + theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))
