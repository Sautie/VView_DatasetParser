
rm(list = ls())
library(lubridate)
df <- read.csv("3nov2022ProjetAI_dxOU.csv", sep = ";", encoding="UTF-8", header=TRUE)
dfH <- read.csv("3nov2022ProjetAI_dxHealthy.csv", sep = ";", encoding="UTF-8", header=TRUE)

dataDemoCouleur <- read.csv("1nov2022ProjetAI_patientDemographicsW.csv", sep = ";", encoding="UTF-8", header=TRUE, na = c(''))
print(apply(dataDemoCouleur, 2, function(col)sum(is.na(col))/length(col)))
dataDemoCouleur <-dataDemoCouleur[!is.na(dataDemoCouleur$COULEUR),]
df<-dfH
couleurdC<-c()
for(i in 1:length(dataDemoCouleur$UID_NUMERO_PATIENT)) {
  for(ii in 1:length(df$UID_NUMERO_PATIENT)) {
    if (df$UID_NUMERO_PATIENT[ii]== dataDemoCouleur$UID_NUMERO_PATIENT[i]) {
      couleurdC<-append(couleurdC,dataDemoCouleur$COULEUR[i])
    }
  }
}

df<-data.frame(table(couleurdC)) # without healthy cats
#df<-df[df$Freq >10,]
df$couleurdC<-factor(df$couleurdC)
df$couleurdC<- factor(df$couleurdC, levels = df$couleurdC[order(df$Freq, decreasing = TRUE)])
#

ggplot(data=df, aes(x=couleurdC, y=Freq))+
  geom_bar(stat="identity", fill="darkmagenta")+
  geom_text(aes(label=Freq),  vjust=-0.3, size=3)+
  #geom_line(aes(x=reorder(patient, -obs), y=obs),  size = 0.8, color="red", group = 1)
  theme(text = element_text(size=12))+
  theme_grey() + theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))
