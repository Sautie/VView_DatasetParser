rm(list = ls())
data <- read.csv("1nov2022ProjetAI_prescriptionsW.csv", sep = ";", encoding="UTF-8", header=TRUE, na = c(''))
nal<-print(apply(data, 2, function(col)sum(is.na(col))/length(col)))
data <-data[!is.na(data$DRUG_NAME),]
# data<-data[!(data$DRUG_NAME %in% c("5867476","631103","3536014A", "6910200", "6888854", "7024086", "11B02S","5972225","606063", "812485","9C3415D",
#                                "35311909A", "20953","30215", "8015869", "05072012/243480","11F06J","9068644","2341693/2342443", "812485",
#                                "956521", "17092014/365003", "5617738", "35207650A", "505353", "5042455")),]
#

patients<-unique(data$UID_NUMERO_PATIENT)
LPatients<-length(patients)
print(LPatients)

drugs<-c()
ddrugsXpatient<-c()
ndrugsXpatient<-c()
patientsP<-c()
j<-1
for(i in 1:LPatients) {
  cn<-0
  d<-0
  diffdrugs<-c()
 # diffOrdonnance<-0 #always different
  while ((patients[i] ==data$UID_NUMERO_PATIENT[j+cn]) &&((cn+j)<length(data$UID_NUMERO_PATIENT)+1))  {
    drugs<-append(drugs,  data$DRUG_NAME[j+cn])
    diffdrugs<-append(diffdrugs,  data$DRUG_NAME[j+cn])
    cn<-cn+1
  }
    ddrugsXpatient<-append(ddrugsXpatient,length(unique(diffdrugs)))
    ndrugsXpatient<-append(ndrugsXpatient, cn)
  j<-j+cn
}
############################################################3
# sorted_drugsXpatient <- sort(ddrugsXpatient,  index.return=TRUE)
# rsorted_drugsXpatient<-rev(sorted_drugsXpatient$x)
# rix<-rev(sorted_drugsXpatient$ix)
#
# rspatients<-c()
# for(i in 1:LPatients) {
#   rspatients<-append(rspatients,patients[[rix[i]]])
# }
#
# dfdrugs<-data.frame(rspatients, rsorted_drugsXpatient)
# write.csv(dfdrugs,file='difdrugs.csv',row.names=FALSE)

# Drugs<-rsorted_drugsXpatient[1:80]
# Patient<-rspatients[1:80]
# df <- data.frame(Patient,Drugs)
# df$Patient <-factor(df$Patient)
# df$Patient<- factor(df$Patient, levels = df$Patient[order(df$Drugs, decreasing = TRUE)])
#
# ggplot(data=df, aes(x=Patient, y=Drugs))+
#   geom_bar(stat="identity", fill="burlywood4")+
#   geom_text(aes(label=Drugs), vjust=1.6, color="white", size=3)+
#   #geom_line(aes(x=reorder(patient, -obs), y=obs),  size = 0.8, color="red", group = 1)
#   theme_grey() + theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))

# df<-data.frame(table(ddrugsXpatient))
# odf<-df[rev(order(df$Freq)),]
# write.csv(odf,file='Freqdfdrugs.csv',row.names=FALSE)

# df<-df[df$Freq >10,]
# df$ddrugsXpatient<-factor(df$ddrugsXpatient)
# df$ddrugsXpatient<- factor(df$ddrugsXpatient, levels = df$ddrugsXpatient[order(df$Freq, decreasing = TRUE)])
#
# ggplot(data=df, aes(x=ddrugsXpatient, y=Freq))+
#   geom_bar(stat="identity", fill="darksalmon")+
#   geom_text(aes(label=Freq),  vjust=-0.3, size=3)+
#   #geom_line(aes(x=reorder(patient, -obs), y=obs),  size = 0.8, color="red", group = 1)
#   theme(text = element_text(size=12))+
#   theme_grey() + theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))




###########################################################3

# sorted_drugsXpatient <- sort(ndrugsXpatient,  index.return=TRUE)
# rsorted_drugsXpatient<-rev(sorted_drugsXpatient$x)
# rix<-rev(sorted_drugsXpatient$ix)
#
# rspatients<-c()
# for(i in 1:LPatients) {
#   rspatients<-append(rspatients,patients[[rix[i]]])
# }
#
# dfdrugs<-data.frame(rspatients, rsorted_drugsXpatient)
# write.csv(dfdrugs,file='Ndrugs.csv',row.names=FALSE)
#
# nDrugs<-rsorted_drugsXpatient[1:80]
# Patient<-rspatients[1:80]
# df <- data.frame(Patient,nDrugs)
# df$Patient <-factor(df$Patient)
# df$Patient<- factor(df$Patient, levels = df$Patient[order(df$nDrugs, decreasing = TRUE)])
#
# ggplot(data=df, aes(x=Patient, y=nDrugs))+
#   geom_bar(stat="identity", fill="burlywood4")+
#   geom_text(aes(label=nDrugs), vjust=1.6, color="white", size=3)+
#   #geom_line(aes(x=reorder(patient, -obs), y=obs),  size = 0.8, color="red", group = 1)
#   theme_grey() + theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))
#
#
# df<-data.frame(table(ndrugsXpatient))
# odf<-df[rev(order(df$Freq)),]
# write.csv(odf,file='FreqNdrugs.csv',row.names=FALSE)
# df<-df[df$Freq >10,]
# df$ndrugsXpatient<-factor(df$ndrugsXpatient)
# df$ndrugsXpatient<- factor(df$ndrugsXpatient, levels = df$ndrugsXpatient[order(df$Freq, decreasing = TRUE)])
#
# ggplot(data=df, aes(x=ndrugsXpatient, y=Freq))+
#   geom_bar(stat="identity", fill="darksalmon")+
#   geom_text(aes(label=Freq),  vjust=-0.3, size=3)+
#   #geom_line(aes(x=reorder(patient, -obs), y=obs),  size = 0.8, color="red", group = 1)
#   theme(text = element_text(size=12))+
#   theme_grey() + theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))


#########################################################################3

df<-data.frame(table(drugs))
odf<-df[rev(order(df$Freq)),]
write.csv(odf,file='Freqdrugs2.csv',row.names=FALSE)

df<-df[df$Freq >300,]
df$drugs<-factor(df$drugs)
df$drugs<- factor(df$drugs, levels = df$drugs[order(df$Freq, decreasing = TRUE)])

ggplot(data=df, aes(x=drugs, y=Freq))+
  geom_bar(stat="identity", fill="chocolate4")+
  geom_text(aes(label=Freq),  vjust=-0.3, size=3)+
  #geom_line(aes(x=reorder(patient, -obs), y=obs),  size = 0.8, color="red", group = 1)
  theme(text = element_text(size=7))+
  theme_grey() + theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))



