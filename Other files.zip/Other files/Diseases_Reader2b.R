rm(list = ls())
df <- read.csv("1nov2022ProjetAI_dxW.csv", sep = ";", encoding="UTF-8", header=TRUE)

data1<-df[df$DX_CODEE %in% c('Examen Normal Pré-Opératoire', 'Examen Normal','Examen Normal Vaccination','Vaccination','Voir Plus Bas', 'Diagnostic(S) Primaire(S)','Codage De Diagnostic','Diagnostic(S) Secondaire(S)', 'Diagnostic ouvert'),]
#data1<- df[grepl("Diagnostic", df$DX_CODEE),]
data<-df[!(df$DX_CODEE %in% c('Examen Normal Pré-Opératoire', 'Examen Normal','Examen Normal Vaccination','Vaccination','Voir Plus Bas' , 'Diagnostic(S) Primaire(S)','Codage De Diagnostic','Diagnostic(S) Secondaire(S)', 'Diagnostic ouvert')),]

DX_CODEEs<-unique(data$DX_CODEE)
LDX_CODEE<-length(DX_CODEEs)
print(LDX_CODEE)
#freq de enfermedad para numero de pacientes diferentes
cont<-c()
contC<-c()
ou<-0
for(s in 1:LDX_CODEE) {
  if (DX_CODEEs[s]=="Obstruction urétrale") {
    ou<-s
    break }
}
mem3<-c()
for(i in 1:LDX_CODEE) {
  mem<-c()
  mem2<-c()
  for(ii in 1:length(data$DX_CODEE)) {
    if (DX_CODEEs[i] ==data$DX_CODEE[ii]&&data$TYPE_DX[ii]=="Definitive")  {
      mem<-append(mem, data$UID_NUMERO_PATIENT[ii])
    }
  }
  for(ii in 1:length(data1$DX_COMMENT)) {
    if (grepl(tolower(DX_CODEEs[i]),  tolower(data1$DX_COMMENT[ii]))&&data1$TYPE_DX[ii]=="Definitive")  {
      mem2<-append(mem2, data1$UID_NUMERO_PATIENT[ii])
      if ((i==1)&&(grepl("obstruction urinaire",  tolower(data1$DX_COMMENT[ii]))) ) {
        mem3<-append(mem3, data1$UID_VISITE[ii])      }
    }
  }

  Lmemo2<-length(unique(mem2))
  Lmemo<-length(unique(mem))
  LmemoC<-Lmemo+Lmemo2
  if ( tolower(DX_CODEEs[i])=="obstruction urétérale") { cont[ou]<-cont[ou]+Lmemo}
  if ((length(mem3)>0)&&(DX_CODEEs[i]=="Obstruction urétrale")) {
    LmemoC<-LmemoC+length(mem3)
    mem3<-c()
  }
  cont<-append(cont, Lmemo) #different visits for DX_CODEE
  contC<-append(contC, LmemoC) #different visits for DX_COMMENT

}

cont2<-c()
cont2C<-c()
cnC3<-0
for(i in 1:LDX_CODEE) {
  cn<-0
  for(ii in 1:length(data$DX_CODEE)) {
    if (DX_CODEEs[i] ==data$DX_CODEE[ii]&&data$TYPE_DX[ii]=="Definitive")  {
      cn<-cn+1
    }
  }
  cnC<-0
  for(ii in 1:length(data1$DX_COMMENT)) {
    if ((grepl(DX_CODEEs[i],  data1$DX_COMMENT[ii]))&&data1$TYPE_DX[ii]=="Definitive")  {
      cnC<-cnC+1
    }
    if ((i==1)&&(grepl("obstruction urinaire",  tolower(data1$DX_COMMENT[ii])))) {
      cnC3<-cnC3+1
          }
  }
  cnC<-cnC+cn
  cont2<-append(cont2, cn)    #for DX_CODEE
  if ( tolower(DX_CODEEs[i])=="obstruction urétérale") { cont2[ou]<-cont2[ou]+cn}
  if ((cnC3>0)&&(DX_CODEEs[i]=="Obstruction urétrale")) {
    cnC<-cnC+cnC3
    cnC3<-0
  }
  cont2C<-append(cont2C, cnC) #for DX_COMMENT

}


sorted <- sort(cont,  index.return=TRUE)
rsorted<-rev(sorted$x)
frrsorted<-rsorted/sum(rsorted)
rix<-rev(sorted $ix)
rsDX_CODEEs<-c()
for(i in 1:LDX_CODEE) {
  rsDX_CODEEs<-append(rsDX_CODEEs,DX_CODEEs[[rix[i]]])
}

sortedC <- sort(contC,  index.return=TRUE)
rsortedC<-rev(sortedC$x)
frrsortedC<-rsortedC/sum(rsortedC)
rixC<-rev(sortedC $ix)
rsDX_CODEEsC<-c()
for(i in 1:LDX_CODEE) {
  rsDX_CODEEsC<-append(rsDX_CODEEsC,DX_CODEEs[[rixC[i]]])
}

###################################################################
#
# patients<-rsorted[1:60]
# DX_CODEEs<-rsDX_CODEEs[1:60]
# df <- data.frame(DX_CODEEs,patients)
# df$DX_CODEEs<-factor(df$DX_CODEEs)
# df$DX_CODEEs<- factor(df$DX_CODEEs, levels = df$DX_CODEEs[order(df$patients, decreasing = TRUE)])
#
# ggplot(data=df, aes(x=DX_CODEEs, y=patients))+
#   geom_bar(stat="identity", fill="darkslateblue")+
#   geom_text(aes(label=patients),  vjust=-0.3, size=3)+
#   #geom_line(aes(x=reorder(patient, -obs), y=obs),  size = 0.8, color="red", group = 1)
#   theme(text = element_text(size=12))+
#   theme_grey() + theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))

patients<-rsortedC[1:60]
DX_CODEE_COMMENTs<-rsDX_CODEEsC[1:60]
df <- data.frame(DX_CODEE_COMMENTs,patients)
df$DX_CODEE_COMMENTs<-factor(df$DX_CODEE_COMMENTs)
df$DX_CODEE_COMMENTs<- factor(df$DX_CODEE_COMMENTs, levels = df$DX_CODEE_COMMENTs[order(df$patients, decreasing = TRUE)])

ggplot(data=df, aes(x=DX_CODEE_COMMENTs, y=patients))+
  geom_bar(stat="identity", fill="darkslateblue")+
  geom_text(aes(label=patients),  vjust=-0.3, size=3)+
  #geom_line(aes(x=reorder(patient, -obs), y=obs),  size = 0.8, color="red", group = 1)
  theme(text = element_text(size=12))+
  theme_grey() + theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))

########################################################################

# sorted2 <- sort(cont2,index.return=TRUE)
# rsorted2<-rev(sorted2 $x)
# frrsorted2<-rsorted2/sum(rsorted2)
# rix2<-rev(sorted2 $ix)
# rsDX_CODEEs2<-c()
# for(i in 1:LDX_CODEE) {
#   rsDX_CODEEs2<-append(rsDX_CODEEs2, DX_CODEEs[[rix2[i]]])
# }
#
# sorted2C <- sort(cont2C,index.return=TRUE)
# rsorted2C<-rev(sorted2C$x)
# frrsorted2C<-rsorted2C/sum(rsorted2C)
# rix2C<-rev(sorted2C$ix)
# rsDX_CODEEs2C<-c()
# for(i in 1:LDX_CODEE) {
#   rsDX_CODEEs2C<-append(rsDX_CODEEs2C, DX_CODEEs[[rix2C[i]]])
# }


df <- data.frame(rsDX_CODEEs,rsorted, frrsorted, rsDX_CODEEsC,rsortedC, frrsortedC)
write.csv(df,file='Patients_DX_CODEEs.csv',row.names=FALSE)



# dfC <- data.frame(rsDX_CODEEsC,rsortedC, frrsortedC, rsDX_CODEEs2C, rsorted2C, frrsorted2C)
# write.csv(dfC,file='Patients_DX_CODEE_Comments.csv',row.names=FALSE)
