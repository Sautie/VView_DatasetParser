rm(list = ls())
library(lubridate)
df <- read.csv("3nov2022ProjetAI_dxOU.csv", sep = ";", encoding="UTF-8", header=TRUE)

dfH <- read.csv("3nov2022ProjetAI_dxHealthy.csv", sep = ";", encoding="UTF-8", header=TRUE)

dataDemoRace <- read.csv("1nov2022ProjetAI_patientDemographicsW.csv", sep = ";", encoding="UTF-8", header=TRUE, na = c(''))
print(apply(dataDemoRace, 2, function(col)sum(is.na(col))/length(col)))
dataDemoRace <-dataDemoRace[!is.na(dataDemoRace$RACE),]

#race and sex distributions for patients with diagnostics
race<-c()
status<-c()
for(i in 1:length(dataDemoRace$UID_NUMERO_PATIENT)) {
  for(j in 1:length(df$UID_NUMERO_PATIENT)) {
    if (dataDemoRace$UID_NUMERO_PATIENT[i] ==df$UID_NUMERO_PATIENT[j])  {
      race<-append(race,dataDemoRace$RACE[i])
      #status<-status+"OU"
    }}
}

aux<-0
raceH<-c()    # for DX_CODEEs all
for(i in 1:length(dataDemoRace$UID_NUMERO_PATIENT)) {
  for(j in 1:length(dfH$UID_NUMERO_PATIENT)) {
    if (dataDemoRace$UID_NUMERO_PATIENT[i] ==dfH$UID_NUMERO_PATIENT[j])  {
       raceH<-append(raceH,dataDemoRace$RACE[i])
       #status<-append(status, "H")
    }}
}


dfrace<-data.frame(table(raceH))
dfrace$raceH<-factor(dfrace$raceH)
dfrace$raceH<- factor(dfrace$raceH, levels = dfrace$raceH[order(dfrace$Freq, decreasing = TRUE)])

#
# ggplot(data=dfrace, aes(x=race, y=Freq))+
#   geom_bar(stat="identity", fill="darkgoldenrod3", width = 0.5)+
#   geom_text(aes(label=Freq),  vjust=-0.3, size=3)+
#   theme(text = element_text(size=30))+
#   theme_grey() + theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))

ggplot(data=dfrace, aes(x=raceH, y=Freq))+
  geom_bar(stat="identity", fill="azure4", width = 0.5)+
  geom_text(aes(label=Freq),  vjust=-0.3, size=3)+
  theme(text = element_text(size=30))+
  theme_grey() + theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))
