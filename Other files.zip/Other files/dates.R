rm(list = ls())
library(lubridate)
data <- read.csv("1nov2022ProjetAI_dxW.csv", sep = ";", encoding="UTF-8", header=TRUE)
patients<-unique(data$UID_NUMERO_PATIENT)
LPatients<-length(patients)
print(LPatients)
# fecha de visitas
visits<-unique(data$UID_VISITE)
Lvisits<-length(visits)
print(Lvisits)

dataD<-data[!(data$DX_CODEE %in% c('Examen Normal Pré-Opératoire', 'Examen Normal','Examen Normal Vaccination','Vaccination','Voir Plus Bas' , 'Diagnostic(S) Primaire(S)','Codage De Diagnostic','Diagnostic(S) Secondaire(S)', 'Diagnostic ouvert')),]
dataH<-data[data$DX_CODEE %in% c('Examen Normal Vaccination','Vaccination'),]

data<-dataH

dates<-c()
datesXPatient<- list()
patientsP<-c()
j<-1
y<-1
visites<-0
for(i in 1:LPatients) {
  cn<-0
  d<-1
  visites<-c()
  datesXPatient[[i]]<-list()
  while ((patients[i] ==data$UID_NUMERO_PATIENT[j+cn]) &&((cn+j)<length(data$UID_NUMERO_PATIENT)+1))  {

    if (cn==0) {
       visites<-append(visites,data$UID_VISITE[j+cn])
       dates<-append(dates,  data$DERNIERE_MODIF_LE[j+cn])
       datesXPatient[[i]]<-append(datesXPatient[[i]],data$DERNIERE_MODIF_LE[j+cn])
       patientsP<-append(patientsP,data$UID_NUMERO_PATIENT[j+cn])
       }
     else
       y<-1
       while (visites[y]!=data$UID_VISITE[j+cn]&&y<length(visites)){
             y<-y+1
               }
     if (y==length(visites)) {
        dates<-append(dates,  data$DERNIERE_MODIF_LE[j+cn])
        #patients<-append(patients,data$UID_NUMERO_PATIENT[j+cn])
        visites<-append(visites,data$UID_VISITE[j+cn])
        datesXPatient[[i]]<-append(datesXPatient[[i]],data$DERNIERE_MODIF_LE[j+cn])
     }

    cn<-cn+1
  }
  j<-j+cn
}

years<-c()
mons<-c()
wdays<-c()
ydays<-c()
for(i in 1:length(dates)) {
  years<-append(years,year(dates[i]))
  mons<-append(mons,month(dates[i], label = TRUE, abbr  = FALSE) )  #, label = TRUE, abbr  = FALSE)
  wdays<-append(wdays,wday(dates[i], label = TRUE, abbr  = FALSE) ) #wday(dates[i], label = TRUE, abbr  = FALSE)
  ydays<-append(ydays,yday(dates[i]))
}

yearsXPatient<- list()
monsXPatient<- list()
wdaysXPatient<- list()
Lsub<-lengths(datesXPatient)
for(i in 1:LPatients) {
  yearsXPatient[[i]]<-list()
  monsXPatient[[i]]<-list()
  wdaysXPatient[[i]]<-list()
  for(ii in 1:Lsub[i]) {
    monsXPatient[[i]]<-append(monsXPatient[[i]], month(datesXPatient[[i]][[ii]]))
    wdaysXPatient[[i]]<-append(wdaysXPatient[[i]],  wday(datesXPatient[[i]][[ii]]))
    yearsXPatient[[i]]<-append(yearsXPatient[[i]],  year(datesXPatient[[i]][[ii]]))

  }
}

years<-data.frame(table(years))
mons<-data.frame(table(mons))
wdays<-data.frame(table(wdays))


ggplot(data=wdays, aes(x=wdays, y=Freq))+
  geom_bar(stat="identity", fill="deepskyblue4")+
  geom_text(aes(label=Freq),  vjust=-0.3, size=3)+
  #geom_line(aes(x=reorder(patient, -obs), y=obs),  size = 0.8, color="red", group = 1)
  theme(text = element_text(size=12))+
  theme_grey() + theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))


# dfm<-data.frame(patientsP, as.matrix(monsXPatient))
# write.csv(dfm,file='MonthsP.csv',row.names=FALSE)
#
# dfd<-data.frame(patientsP, as.matrix(wdaysXPatient))
# write.csv(dfd,file='DaysP.csv',row.names=FALSE)
#
# dfd<-data.frame(patientsP, as.matrix(yearsXPatient))
# write.csv(dfd,file='yearsP.csv',row.names=FALSE)
#
# df<-data.frame(table(wdays))
# odf<-df[rev(order(df$Freq)),]
# #odf<-df[rev(order(df$wdays)),]
#
# write.csv(odf,file='WeekDays.csv',row.names=FALSE)
#
# df<-data.frame(table(mons))
# odf<-df[rev(order(df$Freq)),]
# #odf<-df[rev(order(df$mons)),]
# write.csv(odf,file='Months.csv',row.names=FALSE)
#
# df<-data.frame(table(ydays))
# df<-df[rev(order(df$ydays)),]
# write.csv(odf,file='Ydays.csv',row.names=FALSE)
#
# df<-data.frame(table(years))
# odf<-df[rev(order(df$years)),]
# write.csv(odf,file='years.csv',row.names=FALSE)
