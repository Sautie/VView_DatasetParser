data <- read.csv("1nov2022ProjetAI_sansPrescription.csv", sep = ";", encoding="UTF-8", header=TRUE)
patients<-unique(data$UID_NUMERO_PATIENT)
LPatients<-length(patients)
print(LPatients)


produits<-c()
ProduitsXpatient<-c()
nProduitsXpatient<-c()
patientsP<-c()
j<-1
for(i in 1:LPatients) {
  cn<-0
  d<-0
  diffproduits<-c()
  while ((patients[i] ==data$UID_NUMERO_PATIENT[j+cn]) &&((cn+j)<length(data$UID_NUMERO_PATIENT)+1))  {
    produits<-append(produits,  data$NOM_PRODUIT[j+cn])
    diffproduits<-append(diffproduits,  data$NOM_PRODUIT[j+cn])
    cn<-cn+1
  }
  ProduitsXpatient<-append(ProduitsXpatient,length(unique(diffproduits)))
  nProduitsXpatient<-append(nProduitsXpatient, cn)
  j<-j+cn
}

##########################################################################
sorted_drugsXpatient <- sort(ProduitsXpatient,  index.return=TRUE)
rsorted_drugsXpatient<-rev(sorted_drugsXpatient$x)
rix<-rev(sorted_drugsXpatient$ix)

rspatients<-c()
for(i in 1:LPatients) {
  rspatients<-append(rspatients,patients[[rix[i]]])
}

dfdrugs<-data.frame(rspatients, rsorted_drugsXpatient)
write.csv(dfdrugs,file='difproduits.csv',row.names=FALSE)
#############################################################################
sorted_drugsXpatient <- sort(nProduitsXpatient,  index.return=TRUE)
rsorted_drugsXpatient<-rev(sorted_drugsXpatient$x)
rix<-rev(sorted_drugsXpatient$ix)

rspatients<-c()
for(i in 1:LPatients) {
  rspatients<-append(rspatients,patients[[rix[i]]])
}

dfdrugs<-data.frame(rspatients, rsorted_drugsXpatient)
write.csv(dfdrugs,file='Nproduits.csv',row.names=FALSE)


df<-data.frame(table(produits))
odf<-df[rev(order(df$Freq)),]
write.csv(odf,file='FreqProduits.csv',row.names=FALSE)
