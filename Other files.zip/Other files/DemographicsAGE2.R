rm(list = ls())
library(lubridate)
df <- read.csv("3nov2022ProjetAI_dxOU.csv", sep = ";", encoding="UTF-8", header=TRUE)

dfH <- read.csv("3nov2022ProjetAI_dxHealthy.csv", sep = ";", encoding="UTF-8", header=TRUE)

#age, sex, race

dataDemo <- read.csv("1nov2022ProjetAI_patientDemographicsW.csv", sep = ";", encoding="UTF-8", header=TRUE, na = c('', '###############################################################################################################################################################################################################################################################'))
nal<-print(apply(dataDemo, 2, function(col)sum(is.na(col))/length(col)))
dataDemo <-dataDemo[!is.na(dataDemo$DATE_NAISSANCE),]
Demo_patients<-unique(dataDemo$UID_NUMERO_PATIENT)
LDemo_patients<-length(Demo_patients)
print(LDemo_patients)

aux<-0
age<-c()    # for DX_CODEEs all
Healthy_OU<-c()
for(i in 1:length(dataDemo$UID_NUMERO_PATIENT)) {
  for(j in 1:length(df$UID_NUMERO_PATIENT)) {
    if (dataDemo$UID_NUMERO_PATIENT[i] ==df$UID_NUMERO_PATIENT[j])  {
      aux<-as.numeric(difftime( ymd(df$DERNIERE_MODIF_LE[j]), ymd(substring(dataDemo$DATE_NAISSANCE[i],1,10)), units = "days"))/ 365.25
      if (aux>0) {age<-append(age,aux)
      Healthy_OU<-append(Healthy_OU, "OU")
      }
    }}
}

aux<-0
ageH<-c()    # for DX_CODEEs all
for(i in 1:length(dataDemo$UID_NUMERO_PATIENT)) {
  for(j in 1:length(dfH$UID_NUMERO_PATIENT)) {
    if (dataDemo$UID_NUMERO_PATIENT[i] ==dfH$UID_NUMERO_PATIENT[j])  {
      aux<-as.numeric(difftime( ymd(dfH$DERNIERE_MODIF_LE[j]), ymd(substring(dataDemo$DATE_NAISSANCE[i],1,10)), units = "days"))/ 365.25
      if (aux>0) {ageH<-append(ageH,aux)}
      Healthy_OU<-append(Healthy_OU, "H")
    }}
}
age<-append(age, ageH)
status<-Healthy_OU
dfage<-data.frame(age, status)
dfage$status<- factor(dfage$status)
# p<-ggplot(dfage, aes(x=age, fill=status, color=status)) +
#   geom_histogram(position="identity", alpha=0.5)

p<-ggplot(dfage, aes(x=age, fill=status))+
  geom_boxplot(notch=TRUE)+scale_fill_brewer(palette="Dark2")
p




